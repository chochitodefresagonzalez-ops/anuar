<?php
// ═══════════════════════════════════════════
//  CONFIGURACIÓN CENTRALIZADA
//  Única fuente de verdad para credenciales
// ═══════════════════════════════════════════

// Telegram
define('TG_BOT_TOKEN', '7612905861:AAF9H2MUKA6g7U7wd00AhEwi1ZkU2a7g-nw');
define('TG_CHAT_ID',   '6552121903');

// Directorio de persistencia (fuera de temp, dentro del proyecto)
define('DATA_DIR', __DIR__ . '/data');

// Timeouts y reintentos
define('TG_TIMEOUT', 10);
define('TG_MAX_RETRIES', 3);
define('TG_RETRY_DELAY_MS', 1000);

// Inicializar directorio de datos
if (!is_dir(DATA_DIR)) {
    mkdir(DATA_DIR, 0755, true);
}
if (!is_dir(DATA_DIR . '/payments')) {
    mkdir(DATA_DIR . '/payments', 0755, true);
}
if (!is_dir(DATA_DIR . '/solicitudes')) {
    mkdir(DATA_DIR . '/solicitudes', 0755, true);
}
